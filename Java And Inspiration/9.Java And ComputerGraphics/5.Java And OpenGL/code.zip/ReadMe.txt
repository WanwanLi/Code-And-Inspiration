=================================
      Name:  Kevin Conroy
    E-Mail:  kmconroy@cs.umd.edu
=================================

=================================
System Requirments:
	JOGL, Java, java.awt

	NOTE: You much have JOGL installed on your machine for this program to work!
=================================

=================================
To compile and run type:
	make go
-OR-
	javac *.java
	java MainWindow
=================================


=================================
Info:

* Written in Java using JOGL and java.awt
* Press and hold the ALT key and you can use the ARROW keys to move the triangle
* Press t (lower case) to rotate the triangle 5 degrees CCW
* Press T (upper case) to rotate the triangle 5 degrees CW

=================================

